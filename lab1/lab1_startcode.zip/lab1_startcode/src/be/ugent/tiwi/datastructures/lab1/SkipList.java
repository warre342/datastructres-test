package be.ugent.tiwi.datastructures.lab1;

public class SkipList implements SortedList{
    @Override
    public void insert(int key) {

    }

    @Override
    public boolean contains(int key) {
        return false;
    }

    @Override
    public void remove(int key) {

    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public int[] toArray() {
        return new int[0];
    }

    @Override
    public void clear() {

    }

    @Override
    public void print() {

    }
}
