package be.ugent.tiwi.datastructures.lab3;

/**
 * A Simple BinaryTree class.
 * @author sleroux
 */
public class BinaryTree {

    private BinaryTree left;
    private BinaryTree right;

    // ToDo: add data attributes if needed
    // ToDo: add constructors or methods if needed
    // ToDo: implement toString
    
    public boolean isLeaf() {
        return (left == null) && (right == null);
    }

    public BinaryTree getLeft() {
        return left;
    }

    public void setLeft(BinaryTree left) {
        this.left = left;
    }

    public BinaryTree getRight() {
        return right;
    }

    public void setRight(BinaryTree right) {
        this.right = right;
    }

    @Override
    public String toString() {
        // ToDo: implement this
        return null;
    }

}
