package be.ugent.tiwi.datastructures.lab2;

import java.util.List;
import java.util.Map;

/**
 *
 * @author sleroux
 */
public class BinaryTree {

    private BinaryTree left;
    private BinaryTree right;
    private String value;
    
    public boolean build(List<String> questions, List<String> animals, List<Map<String, Boolean>> answers){
        return false;
    }
    
    public int height(){
        return 0;
    }
    
    public double averageDepth(){
        return 0;
    }

    @Override
    public String toString() {
        return "";
    }
    
}
